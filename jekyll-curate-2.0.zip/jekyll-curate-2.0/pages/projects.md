---
layout: projects
title: Projects
permalink: "/projects/"

projects:
  heading: "" # "Projects"
  sub_heading: "" # "A collection of our recent work"
  limit: 96
  sort: date # date | weight
  view_more_button_text: "" # "More Projects"
  view_more_button_link: "" # "/projects"
  columns: 4 # 1 | 2 | 3 | 4
---
